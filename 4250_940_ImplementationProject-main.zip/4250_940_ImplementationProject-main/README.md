# 4250_940_ImplementationProject

In-class project, taking option 1 (recursive numbers)
